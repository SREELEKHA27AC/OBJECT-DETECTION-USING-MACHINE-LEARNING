# Real-Time Object Detection using YOLO

This project implements a real-time object detection system using YOLOv5. The model is trained on a custom dataset with 10+ classes and achieves ~85% accuracy.

## Features
- Real-time inference
- Custom training on 500+ images
- 20ms inference time per frame

## Installation
```bash
pip install -r requirements.txt
```

## Training
```bash
python scripts/train.py --img 640 --batch 16 --epochs 50 --data config/data.yaml --weights models/yolov5s.pt
```

## Detection
```bash
python scripts/detect.py --source data/images --weights models/yolov5s.pt --conf 0.4
```
